//
//  Scene.swift
//  District-Mystery
//
//  Created by Ana Da hora on 09/09/18.
//  Copyright © 2018 DaHora. All rights reserved.
//

import SpriteKit
import ARKit

class Scene: SKScene {
    
    override func didMove(to view: SKView) {
        // Setup your scene here
    }
    
    override func update(_ currentTime: TimeInterval) {
        // Called before each frame is rendered
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        
        guard let sceneView = self.view as? ARSKView else {
            return
        }
        if let touchLocation = touches.first?.location(in: sceneView) {
            let hitResultsFeaturePoints: [ARHitTestResult] = sceneView.hitTest(touchLocation, types: .featurePoint)
            if let hit = hitResultsFeaturePoints.first {
                // Get a transformation matrix with the euler angle of the camera
                let rotate = simd_float4x4(SCNMatrix4MakeRotation(sceneView.session.currentFrame!.camera.eulerAngles.y, 0, 1, 0))
                // Combine both transformation matrices
                let finalTransform = simd_mul(hit.worldTransform, rotate)
                
                // Use the resulting matrix to position the anchor
                sceneView.session.add(anchor: ARAnchor(transform: finalTransform))
            }
        }
}

}


